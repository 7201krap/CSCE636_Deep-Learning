import os
import pickle
import numpy as np

""" This script implements the functions for reading data.
"""

def load_data(data_dir):
    """ Load the CIFAR-10 dataset.

    Args:
        data_dir: A string. The directory where data batches are stored.
    
    Returns:
        x_train: An numpy array of shape [50000, 3072]. 
        (dtype=np.float32)
        y_train: An numpy array of shape [50000,]. 
        (dtype=np.int32)
        x_test: An numpy array of shape [10000, 3072]. 
        (dtype=np.float32)
        y_test: An numpy array of shape [10000,]. 
        (dtype=np.int32)
    """
    ### YOUR CODE HERE

    # There are 6 batches: 5 training batches and 1 test batch.
    # 1: We first deal with 5 training batches
    for i in range(1, 6):
        train_files = os.path.join(data_dir, f'data_batch_{i}')
        # open 
        train_open = open(train_files, 'rb')
        train_data = pickle.load(train_open, encoding='latin1')
        # close
        train_open.close()
    
        if i == 1:
            x_train = np.array(train_data['data'])
            y_train = np.array(train_data['labels'])
        else:
            x_train = np.vstack((x_train, train_data['data']))
            y_train = np.hstack((y_train, train_data['labels']))

    # 2: We now deal with the test data
    test_files = os.path.join(data_dir, 'test_batch')
    # open 
    test_open = open(test_files, 'rb')
    test_data = pickle.load(test_open, encoding='latin1')
    # close 
    test_open.close()

    x_test = np.array(test_data['data'])
    y_test = np.array(test_data['labels'])

    # Debugging 
    # print(x_train.shape)
    # print(y_train.shape)
    # print(x_test.shape) 
    # print(y_test.shape)

    print("finished function: load_data")
    ### YOUR CODE HERE

    return x_train, y_train, x_test, y_test

def train_vaild_split(x_train, y_train, split_index=45000):
    """ Split the original training data into a new training dataset
        and a validation dataset.
    
    Args:
        x_train: An array of shape [50000, 3072].
        y_train: An array of shape [50000,].
        split_index: An integer.

    Returns:
        x_train_new: An array of shape [split_index, 3072].
        y_train_new: An array of shape [split_index,].
        x_valid: An array of shape [50000-split_index, 3072].
        y_valid: An array of shape [50000-split_index,].
    """
    x_train_new = x_train[:split_index]
    y_train_new = y_train[:split_index]
    x_valid = x_train[split_index:]
    y_valid = y_train[split_index:]

    return x_train_new, y_train_new, x_valid, y_valid